package com.example.space_pod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
