import 'package:flutter/material.dart';
import 'package:space_pod/pages/home_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          brightness: Brightness.dark,
          fontFamily: 'Bahnscrift-light',
          scaffoldBackgroundColor: Color(0xa5111414),
          primaryColor: Color(0xff2ddae0)),
    );
  }
}
